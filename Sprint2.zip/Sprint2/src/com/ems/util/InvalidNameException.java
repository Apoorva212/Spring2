package com.ems.util;

public class InvalidNameException extends RuntimeException {
	public InvalidNameException(String msg){
		super(msg);
	}
}
