package com.ems.util;

public class InvalidDobException extends RuntimeException {
	public  InvalidDobException(String msg) {
		super(msg);
	}

}
