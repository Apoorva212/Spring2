package com.ems.configuration;

import java.sql.Connection;
import java.sql.DriverManager;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ems.application.EmployeeManagementApp;
import com.ems.dao.EmployeeDaoImp;
import com.ems.service.EmployeeServiceImp;


	@Configuration
	@ComponentScan("com.ems")
	public class EmsConfig {
		@Bean("con")
		public Connection getConnection() throws Exception
		{
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/ems","apoorva","app123");
			return con;
		}
		@Bean("dao")
		public EmployeeDaoImp getEmpDao()
	
		{
			EmployeeDaoImp dao=new EmployeeDaoImp();
			return dao;
		}
		
		@Bean("es")
		public EmployeeServiceImp getEmpService()
	
		{
			EmployeeServiceImp es=new EmployeeServiceImp();
			es.setDao(getEmpDao());
			return es;
		}
		@Bean("app")
		public EmployeeManagementApp getApp()
	
		{
			EmployeeManagementApp app=new EmployeeManagementApp();
			app.setEs(getEmpService());
			return app;
		}
	
}
