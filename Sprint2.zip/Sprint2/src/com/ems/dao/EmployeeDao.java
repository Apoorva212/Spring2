package com.ems.dao;
import com.ems.model.Employee;
import java.sql.Connection;
import java.util.List;
public interface EmployeeDao {
	//public boolean validateEmployee(Employee emp) throws Exception;
	public Connection getConnection() throws Exception;
	public String generatedId(String empName)throws Exception;
	public boolean save(Employee emp)throws Exception;
	public boolean delete(String empId)throws Exception;
	public boolean update(Employee emp)throws Exception;
	public Employee getEmployee(String empId)throws Exception;
    public List<Employee> getAllEmployees()throws Exception;
}
